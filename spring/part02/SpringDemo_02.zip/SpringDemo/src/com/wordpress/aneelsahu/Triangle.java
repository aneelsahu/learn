package com.wordpress.aneelsahu;

public class Triangle {
	
	public void draw(){
		System.out.println("Triangle Drawn");
	}

}
