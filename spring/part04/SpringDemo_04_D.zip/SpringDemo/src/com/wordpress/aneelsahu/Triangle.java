package com.wordpress.aneelsahu;

public class Triangle {
	
	String type;
	int height;
	
	Triangle(int height) {
		this.height = height;		
	}
	
	Triangle(String type) {
		this.type = type;		
	}
	

	Triangle(String type,int height) {
		this.type = type;
		this.height = height;
	}
	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @return the height
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * @param type the type to set
	 */
	
//	public void setType(String type) {
//		this.type = type;
//	}

	public void draw(){
		System.out.println("Triangle Drawn type is "+type+" and height is " + height);
	}

}
