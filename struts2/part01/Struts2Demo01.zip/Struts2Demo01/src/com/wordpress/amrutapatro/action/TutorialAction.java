 /*       
  * Author : Amruta Patro 
  * Date   : Dec/20/2012
  * Email  : amyy.ca@gmail.com
  * Blog   : http://amrutapatro.wordpress.com 
  */   
package com.wordpress.amrutapatro.action;

import com.opensymphony.xwork2.Action;


public class TutorialAction implements Action {
	
	@Override
	public String execute() throws Exception{		
		System.out.println("Inside Turorial Action");
		return "success";
	}

}
