
/*       
  * Author : Amruta Patro 
  * Date   : Dec/20/2012
  * Email  : amyy.ca@gmail.com
  * Blog   : http://amrutapatro.wordpress.com 
  */   
package com.wordpress.amrutapatro.action;

import com.wordpress.amrutapatro.service.TutorialFinderService;

public class TutorialAction {
	
	private String bestTutSite;
	private String language;

	public String execute(){
		
		System.out.println("Inside Turorial Action");
		TutorialFinderService tfs=new TutorialFinderService();
		bestTutSite=tfs.getBestTutorials(getLanguage());
		setBestTutSite(bestTutSite);
		System.out.println(bestTutSite);
		return "success";
	}
	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}


	/**
	 * @return the bestTutSite
	 */
	public String getBestTutSite() {
		return bestTutSite;
	}

	/**
	 * @param bestTutSite the bestTutSite to set
	 */
	public void setBestTutSite(String bestTutSite) {
		this.bestTutSite = bestTutSite;
	}

}
