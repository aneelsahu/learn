/*       
 * Author : Amruta Patro 
 * Date   : Dec/20/2012
 * Email  : amyy.ca@gmail.com
 * Blog   : http://amrutapatro.wordpress.com 
 */
package com.wordpress.amrutapatro.service;

public class TutorialFinderService {

	public String getBestTutorials(String lang) {
		String response;
		if (lang.equals("Java")) {
			response = "Best Java Tutorial Site is Google";
		} else {
			response = "I dont have any idea";
		}
		return response;
	}
}
