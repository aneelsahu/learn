package org.ams.javabrains.action;
import org.ams.javabrains.service.TutorialFinderService;
public class TutorialAction {
	
	public String execute(){
		
		System.out.println("Inside Turorial Action");
		TutorialFinderService tfs=new TutorialFinderService();
		String BestTutSite=tfs.getBestTutorials();
		System.out.println(BestTutSite);
		return "success";
	}

}
