package org.ams.javabrains.service;

public class TutorialFinderService {

public String getBestTutorials(){
	
	return "Java Brains";
}
}
