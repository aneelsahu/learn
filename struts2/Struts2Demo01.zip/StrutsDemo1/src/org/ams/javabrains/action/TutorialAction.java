package org.ams.javabrains.action;

public class TutorialAction {
	
	public String execute(){
		System.out.println("Hello This Struts DEMO 1 ");
		return "success";
	}

}
