
/*       
  * Author : Amruta Patro 
  * Date   : Dec/20/2012
  * Email  : amyy.ca@gmail.com
  * Blog   : http://amrutapatro.wordpress.com 
  */   
package com.wordpress.amrutapatro.action;

import com.wordpress.amrutapatro.service.TutorialFinderService;
public class TutorialAction {
	
	public String execute(){
		
		System.out.println("Inside Turorial Action");
		TutorialFinderService tfs=new TutorialFinderService();
		String BestTutSite=tfs.getBestTutorials();
		System.out.println(BestTutSite);
		return "success";
	}

}
