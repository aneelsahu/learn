/*       
  * Author : Amruta Patro 
  * Date   : Dec/20/2012
  * Email  : amyy.ca@gmail.com
  * Blog   : http://amrutapatro.wordpress.com 
  */   
package com.wordpress.amrutapatro.service;

public class TutorialFinderService {

public String getBestTutorials(){
	
	return "Best Java Tutorial Site is Google";
}
}
