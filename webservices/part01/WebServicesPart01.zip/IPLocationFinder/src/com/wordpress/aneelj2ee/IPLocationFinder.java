package com.wordpress.aneelj2ee;

import net.webservicex.GeoIP;
import net.webservicex.GeoIPService;
import net.webservicex.GeoIPServiceSoap;

/*
 * Simple Web Service call
 * author: asahu 
 */

public class IPLocationFinder {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		if(args.length!=1){
			System.out.println("Please pass the IP Address as input Ex: 74.125.239.142 for Google.com  ");
		}else{			
			String ipAddress = args[0];
			GeoIPService geoIPServ = new GeoIPService();
			GeoIPServiceSoap geoIpServSoap = geoIPServ.getGeoIPServiceSoap();		
			GeoIP geoIpResponse = geoIpServSoap.getGeoIP(ipAddress);		
			System.out.println(" Country Name is :"+geoIpResponse.getCountryName());			
		}

	}

}
